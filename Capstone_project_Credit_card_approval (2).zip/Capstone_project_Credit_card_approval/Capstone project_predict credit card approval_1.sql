create database Credit_card;

use credit_card;

select * from credit_card_final;

desc credit_card_final;

select count(*) from credit_card_final;  -- total rows count(*)

-- 1. Group the customers based on their income type and find the average of their annual income.

select * from credit_card_final;

SELECT type_income, AVG(annual_income) AS average_income
FROM credit_card_final
GROUP BY type_income;

-- 2. Find the female owners of cars and property?

select * from credit_card_final;

SELECT *
FROM credit_card_final
WHERE GENDER = 'F' AND Car_Owner = 'Y' AND Propert_Owner = 'Y';

-- 3. Find the male customers who are staying with their families.

select * from credit_card_final;

SELECT *
FROM credit_card_final
WHERE GENDER = 'M' AND Marital_status = 'Married' AND Housing_type = 'House / apartment';

-- 4. Please list the top five people having the highest income.

select * from credit_card_final;

SELECT *
FROM credit_card_final
ORDER BY Annual_income DESC
LIMIT 5;

-- 5. How many married people are having bad credit?

select * from credit_card_final;

SELECT AVG(annual_income) AS average_income
FROM credit_card_final;

SELECT COUNT(*) AS num_married_low_income
FROM credit_card_final
WHERE Marital_status = 'Married' AND Annual_income < (SELECT AVG(annual_income) FROM credit_card_final WHERE annual_income IS NOT NULL);

-- 6. What is the highest education level and what is the total count?

select * from credit_card_final;

SELECT COUNT(*) AS higher_education_count
FROM credit_card_final
WHERE EDUCATION = 'Higher education';

-- 7. Between married males and females, who is having more bad credit?

SELECT Marital_status, GENDER, COUNT(*) AS num_bad_income
FROM credit_card_final
WHERE Annual_income < (SELECT AVG(annual_income) FROM credit_card_final WHERE annual_income IS NOT NULL)
  AND Marital_status = 'Married'
  AND GENDER IN ('M', 'F')
GROUP BY Marital_status, GENDER;

